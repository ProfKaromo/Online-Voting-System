# downtime-timer
Website downtime timer prototype, built with jQuery and moment.js. Timer remains consistent regardless of time zone.

To set end date/time change string value in config object within timer.js i.e. endDate: '2016-05-19 09:00'

Demo: https://jsfiddle.net/deLpu7jj/4/
